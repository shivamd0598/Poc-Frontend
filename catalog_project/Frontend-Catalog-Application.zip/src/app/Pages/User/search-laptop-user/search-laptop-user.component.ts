import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-search-laptop-user',
  templateUrl: './search-laptop-user.component.html',
  styleUrls: ['./search-laptop-user.component.css']
})
export class SearchLaptopUserComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
