export class Vendor{
    id:number;
    name:String;
    rating:number;
    address:String;
    contactNo:String;
}